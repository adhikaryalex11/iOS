//
//  StudentCell.swift
//  DynamicTableDemo
//
//  Created by Azad on 2022/11/02.
//

import UIKit

class StudentCell: UIViewController ,UITableViewDataSource ,UITableViewDelegate{
    
 
    
    var students:[Student] = []
    @IBOutlet weak var tb_student: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        var i=0
        while i<10{
            let student=Student(id:"100\(i)", name:"Azad\(i)", number: "19L55\(i)", photo:"")
            students.append(student)
            i=i+1
        }
        tb_student.dataSource = self
        tb_student.delegate=self

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return students.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tb_student.dequeueReusableCell(withIdentifier: "Stutacell", for: indexPath) as? StudentTableViewCell
        
        cell?.lbname.text = students[indexPath.row].name
        cell?.lbnumber.text = students[indexPath.row].number
        cell?.imgPhoto.image = UIImage(named: "2")
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let stuname = students[indexPath.row].name
        print(stuname)
    }
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
        return "Delete"
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            //for showing alert dialog
                let alert = UIAlertController(title: "Message", message: "are you sure to delete the row?", preferredStyle: .alert)
                let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                let ok = UIAlertAction(title: "OK", style: .default){ (action) in
                    //write your delete code here
                    self.students.remove(at: indexPath.row)
                    self.tb_student.reloadData()
                }
                alert.addAction(cancel)
                alert.addAction(ok)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    

