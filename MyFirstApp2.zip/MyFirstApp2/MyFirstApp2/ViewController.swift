//
//  ViewController.swift
//  MyFirstApp2
//
//  Created by ios06 on 10/31/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

