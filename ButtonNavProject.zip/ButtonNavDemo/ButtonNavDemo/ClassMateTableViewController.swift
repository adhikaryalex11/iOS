//
//  ClassMateTableViewController.swift
//  ButtonNavDemo
//
//  Created by ios06 on 11/8/22.
//

import UIKit

class ClassmateTableViewCell: UITableViewCell {

    @IBOutlet weak var lbId: UILabel!
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
