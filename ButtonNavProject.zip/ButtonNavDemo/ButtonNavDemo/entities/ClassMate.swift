//
//  ClassMate.swift
//  ButtonNavDemo
//
//  Created by ios06 on 11/8/22.
//

import UIKit

class ClassMate {

    public var id:String=""
    public var name:String=""
    public var number:String=""
}
