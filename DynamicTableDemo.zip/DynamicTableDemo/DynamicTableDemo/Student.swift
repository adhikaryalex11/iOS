//
//  Student.swift
//  DynamicTableDemo
//
//  Created by Azad on 2022/11/02.
//

import UIKit

class Student{
    var id:String
    var name:String
    var number:String
    var photo:String
    init(id:String,name:String,number:String,photo:String) {
        self.id = id
        self.name = name
        self.number = number
        self.photo = photo
    }
    
    
    
    

}
