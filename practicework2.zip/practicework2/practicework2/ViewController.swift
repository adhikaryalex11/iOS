//
//  ViewController.swift
//  practicework2
//
//  Created by ios06 on 11/25/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet var Alabel: [UILabel]!
    
    @IBOutlet weak var ulabel: UILabel!
    
    @IBOutlet weak var plabel: UILabel!
    
    @IBOutlet weak var elabel: UILabel!
    
    @IBOutlet weak var passlabel: UILabel!
    
    @IBOutlet weak var lbutton: UIButton!
    
    @IBOutlet weak var sbutton: UIButton!
    
    @IBOutlet weak var utextfield: UITextField!
    
    @IBOutlet weak var ptextfield: UITextField!
    
    @IBOutlet weak var etextfield: UITextField!
    
    @IBOutlet weak var passfield: UITextField!
}

