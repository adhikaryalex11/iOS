//
//  MyViewController.swift
//  MyFirstApp2
//
//  Created by ios06 on 11/5/22.
//

import UIKit

class MyViewController: UIViewController {

    @IBOutlet weak var sw_sex: UISwitch!
    @IBOutlet weak var slider_age: UISlider!
    @IBOutlet weak var segment_3: UISegmentedControl!
    @IBOutlet weak var txt_user: UITextField!
    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var txt_phone: UITextField!
    @IBOutlet weak var txt_password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        txt_user.textContentType = .name
        segment_3.selectedSegmentIndex = 1
        
        slider_age.minimumValue = 0
        slider_age.maximumValue = 200
        slider_age.value = 75
        
        sw_sex.setOn(true, animated: true)
        
    }
    
    @IBOutlet weak var delete_button: UIButton!
    
    @IBAction func sw_sex_touch_down(_ sender: Any) {
        print("sw_sex_touch_down")
    }
    @IBAction func segment_3_touch_down(_ sender: Any) {
        print("segment_3_touch_down")
    }
    
    @IBAction func btn_touch_down(_ sender: Any) {
        txt_user.text = "Alex Adhikary"
        txt_email.text = "alex19980411@protonmail.com"
        txt_phone.text = "+8613078778684"
        txt_password.text = "Art67890"
    }
    
    @IBAction func btn_touch_down_repeat(_ sender: Any) {
        txt_user.text = "Ondrilla Ria"
        txt_email.text = "aor@protonmail.com"
        txt_phone.text = "+88016457890"
        txt_password.text = "Art778900"
    }
    
    @IBAction func seg_info_value_changed(_ sender: Any) {
        print(segment_3.selectedSegmentIndex)
        if let title = segment_3.titleForSegment(at: segment_3.selectedSegmentIndex){
        print(title)
    }
}
    
    @IBAction func slider_age_value_changed(_ sender: Any) {
        print(slider_age.value)
    }
    @IBAction func sw_sex_value_changed(_ sender: Any) {
        if sw_sex.isOn {
            print("male")
        }else{
            print("female")
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
