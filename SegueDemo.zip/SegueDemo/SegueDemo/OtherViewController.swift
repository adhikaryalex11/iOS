//
//  OtherViewController.swift
//  SegueDemo
//
//  Created by ios06 on 11/29/22.
//

import UIKit

class OtherViewController: UIViewController {

    
    
    @IBOutlet weak var lbUsername: UILabel!
    var userName:String =  ""
    override func viewDidLoad() {
        super.viewDidLoad()
        lbUsername.text = userName
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btnBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    

}
