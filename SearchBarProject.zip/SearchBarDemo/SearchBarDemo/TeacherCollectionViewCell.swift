//
//  TeacherCollectionViewCell.swift
//  SearchBarDemo
//
//  Created by ios06 on 11/26/22.
//

import UIKit

class TeacherCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img_photo: UIImageView!
    @IBOutlet weak var lab_name: UILabel!
    
}
