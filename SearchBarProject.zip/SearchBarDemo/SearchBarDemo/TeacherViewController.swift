//
//  TeacherViewController.swift
//  SearchBarDemo
//
//  Created by ios06 on 11/26/22.
//

import UIKit

class TeacherViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    var teachers = ["Gu donghu", "Zhu Xiaojing", "Zhang", "Sun Shiyun", "Sabrina", "Catherine"]
    

    @IBOutlet weak var collection_teacher: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width:100, height:100)
        collection_teacher.collectionViewLayout = layout

        collection_teacher.dataSource = self
        collection_teacher.delegate = self
        // Do any additional setup after loading the view.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return teachers.count
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
   
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"teachercell", for: indexPath) as! TeacherCollectionViewCell
        cell.img_photo.image = UIImage(named: "wlogo")
        cell.lab_name.text = teachers[indexPath.item]
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
