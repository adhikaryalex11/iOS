//
//  ViewController.swift
//  SegueDemo
//
//  Created by ios06 on 11/29/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtUserName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnOpenUI(_ sender: Any) {
        self.performSegue(withIdentifier: "login", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="login" {
            let otherViewController = segue.destination as! OtherViewController
        otherViewController.userName = txtUserName.text ?? ""
            
        }
    }
}

