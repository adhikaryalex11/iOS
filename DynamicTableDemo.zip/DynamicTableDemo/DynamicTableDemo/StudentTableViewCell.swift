//
//  StudentTableViewCell.swift
//  DynamicTableDemo
//
//  Created by Azad on 2022/11/02.
//

import UIKit

class StudentTableViewCell: UITableViewCell {
    

    @IBOutlet weak var lbname: UILabel!
    @IBOutlet weak var lbnumber: UILabel!
    @IBOutlet weak var imgPhoto: UIImageView!
    //    @IBOutlet weak var img_pic: UIImageView!
//
//    @IBOutlet weak var lb_name: UILabel!
//    @IBOutlet weak var lb_number: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        imgPhoto.layer.cornerRadius = 20
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
