//
//  ViewController.swift
//  DynamicTableDemo
//
//  Created by i06 on 2022/11/02.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
  
    var studedentsNames = ["sasa","rara","irara","lili","didi"]
    var teacherNames = ["ssss","rrrr","irri","llll","dddd"]

    @IBOutlet weak var Student_tab: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Student_tab.dataSource = self
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return teacherNames.count
    }
    func tableView(_tableView: UITableView, numberofRowsInSection section: Int) ->String? {
        if section == 0{
            return "student"
        }else{
            return "teacher"
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studedentsNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let nameCell = Student_tab.dequeueReusableCell(withIdentifier: "stuname", for: indexPath)
        nameCell.textLabel?.text = studedentsNames[indexPath.row]
        return nameCell
    }
    

}

