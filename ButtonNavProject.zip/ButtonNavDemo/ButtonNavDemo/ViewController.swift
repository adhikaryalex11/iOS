//
//  ViewController.swift
//  ButtonNavDemo
//
//  Created by ios06 on 11/8/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

